package com.example.carrenting.entity;

public enum Position {
    EMPLOYEE, MANAGER
}
