package com.example.carrenting.entity;

public enum Status {
    FREE, OCCUPIED
}
