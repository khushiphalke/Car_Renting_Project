package com.example.carrenting;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class CarRentingApplicationTests {

	@Test
	void contextLoads() {
	}

}
